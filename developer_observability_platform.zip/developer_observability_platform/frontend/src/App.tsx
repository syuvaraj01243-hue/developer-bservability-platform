import { useEffect, useState } from "react"
import { Activity, AlertTriangle, Clock3, Database, Gauge, Server, ShieldAlert, RefreshCw } from "lucide-react"
import { AreaChart, Area, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"

const API = "http://127.0.0.1:8000/api"

type Metrics = {
  request_count:number; error_count:number; error_rate:number;
  avg_latency_ms:number; p50_latency_ms:number; p95_latency_ms:number; p99_latency_ms:number
}
type Service = {id:number; name:string; environment:string; version:string; status:string}
type Log = {id:number; service:string; level:string; message:string; created_at:string}

async function get<T>(path:string):Promise<T>{
  const r = await fetch(API + path)
  if(!r.ok) throw new Error(await r.text())
  return r.json()
}

function Card({icon, label, value, sub}:{icon:any,label:string,value:any,sub:string}){
  return <div className="card metric"><div className="metric-icon">{icon}</div><div><div className="muted">{label}</div><div className="metric-value">{value}</div><div className="sub">{sub}</div></div></div>
}

export default function App(){
  const [metrics,setMetrics] = useState<Metrics|null>(null)
  const [services,setServices] = useState<Service[]>([])
  const [logs,setLogs] = useState<Log[]>([])
  const [error,setError] = useState("")
  const load = async()=>{
    try{
      setError("")
      const [m,s,l] = await Promise.all([
        get<Metrics>("/metrics/overview"),
        get<Service[]>("/services"),
        get<Log[]>("/logs?limit=12")
      ])
      setMetrics(m); setServices(s); setLogs(l)
    }catch(e){setError("Backend unavailable. Start FastAPI on port 8000.")}
  }
  useEffect(()=>{load()},[])
  const chart = metrics ? [
    {name:"P50", value:metrics.p50_latency_ms},
    {name:"Average", value:metrics.avg_latency_ms},
    {name:"P95", value:metrics.p95_latency_ms},
    {name:"P99", value:metrics.p99_latency_ms}
  ] : []

  return <div className="app">
    <aside>
      <div className="brand"><div className="brand-mark"><Activity size={21}/></div><div><b>ObserveX</b><span>Developer Observability</span></div></div>
      <nav><div className="nav active"><Gauge size={18}/> Overview</div><div className="nav"><Server size={18}/> Services</div><div className="nav"><Activity size={18}/> Traces</div><div className="nav"><Database size={18}/> Logs</div><div className="nav"><AlertTriangle size={18}/> Alerts</div><div className="nav"><ShieldAlert size={18}/> Incidents</div></nav>
      <div className="side-bottom"><span className="dot"></span> API connected</div>
    </aside>
    <main>
      <header><div><h1>System Overview</h1><p>Monitor services, performance and reliability in one place.</p></div><button onClick={load}><RefreshCw size={16}/> Refresh</button></header>
      {error && <div className="error">{error}</div>}
      {metrics && <section className="grid">
        <Card icon={<Activity/>} label="Requests" value={metrics.request_count.toLocaleString()} sub={`${metrics.error_count} server errors`}/>
        <Card icon={<AlertTriangle/>} label="Error rate" value={`${metrics.error_rate}%`} sub="5xx responses"/>
        <Card icon={<Clock3/>} label="P95 latency" value={`${metrics.p95_latency_ms} ms`} sub={`P99 ${metrics.p99_latency_ms} ms`}/>
        <Card icon={<Server/>} label="Services" value={services.length} sub="registered services"/>
      </section>}
      <section className="two">
        <div className="card panel"><div className="panel-head"><div><h2>Latency distribution</h2><p>Current request performance</p></div><span className="pill">ms</span></div>
          <div className="chart"><ResponsiveContainer width="100%" height="100%"><AreaChart data={chart}><XAxis dataKey="name"/><YAxis/><Tooltip/><Area type="monotone" dataKey="value" fillOpacity={0.22} strokeWidth={2}/></AreaChart></ResponsiveContainer></div>
        </div>
        <div className="card panel"><div className="panel-head"><div><h2>Services</h2><p>Current health</p></div></div>
          <div className="service-list">{services.map(s=><div className="service" key={s.id}><div className="service-name"><span className="health"></span><div><b>{s.name}</b><small>{s.environment} · v{s.version}</small></div></div><span className="healthy">{s.status}</span></div>)}</div>
        </div>
      </section>
      <section className="card panel"><div className="panel-head"><div><h2>Recent logs</h2><p>Latest events across your services</p></div><span className="pill">{logs.length} events</span></div>
        <div className="logs">{logs.map(l=><div className="log" key={l.id}><span className={`level ${l.level.toLowerCase()}`}>{l.level}</span><b>{l.service}</b><span className="message">{l.message}</span><time>{new Date(l.created_at).toLocaleTimeString()}</time></div>)}</div>
      </section>
    </main>
  </div>
}
