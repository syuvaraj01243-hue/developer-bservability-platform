from datetime import datetime
from pydantic import BaseModel, ConfigDict

class ServiceIn(BaseModel):
    name: str
    environment: str = "development"
    version: str = "1.0.0"

class TraceIn(BaseModel):
    service: str
    method: str = "GET"
    route: str = "/"
    status_code: int = 200
    latency_ms: float = 0
    trace_id: str | None = None

class LogIn(BaseModel):
    service: str
    level: str = "INFO"
    message: str
    trace_id: str | None = None

class AlertIn(BaseModel):
    name: str
    metric: str
    operator: str = ">"
    threshold: float
    enabled: bool = True

class IncidentIn(BaseModel):
    title: str
    severity: str = "medium"
    service: str | None = None
    description: str = ""

class ServiceOut(ServiceIn):
    model_config = ConfigDict(from_attributes=True)
    id: int
    status: str
    last_seen: datetime

class IncidentOut(IncidentIn):
    model_config = ConfigDict(from_attributes=True)
    id: int
    status: str
    created_at: datetime
    resolved_at: datetime | None
