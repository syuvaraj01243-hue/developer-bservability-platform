from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Float, DateTime, Text, Boolean
from .database import Base

def now():
    return datetime.now(timezone.utc)

class Service(Base):
    __tablename__ = "services"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), unique=True, nullable=False)
    environment = Column(String(40), default="development")
    status = Column(String(30), default="healthy")
    version = Column(String(40), default="1.0.0")
    last_seen = Column(DateTime, default=now)
    created_at = Column(DateTime, default=now)

class RequestTrace(Base):
    __tablename__ = "request_traces"
    id = Column(Integer, primary_key=True)
    service = Column(String(120), nullable=False)
    method = Column(String(10), default="GET")
    route = Column(String(255), default="/")
    status_code = Column(Integer, default=200)
    latency_ms = Column(Float, default=0)
    trace_id = Column(String(80))
    created_at = Column(DateTime, default=now)

class LogEntry(Base):
    __tablename__ = "logs"
    id = Column(Integer, primary_key=True)
    service = Column(String(120), nullable=False)
    level = Column(String(20), default="INFO")
    message = Column(Text, nullable=False)
    trace_id = Column(String(80))
    created_at = Column(DateTime, default=now)

class AlertRule(Base):
    __tablename__ = "alert_rules"
    id = Column(Integer, primary_key=True)
    name = Column(String(150), nullable=False)
    metric = Column(String(80), nullable=False)
    operator = Column(String(10), default=">")
    threshold = Column(Float, nullable=False)
    enabled = Column(Boolean, default=True)
    created_at = Column(DateTime, default=now)

class Incident(Base):
    __tablename__ = "incidents"
    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    severity = Column(String(30), default="medium")
    status = Column(String(30), default="open")
    service = Column(String(120))
    description = Column(Text, default="")
    created_at = Column(DateTime, default=now)
    resolved_at = Column(DateTime, nullable=True)
