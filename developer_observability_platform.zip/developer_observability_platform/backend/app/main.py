from datetime import datetime, timezone
from statistics import mean
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from .database import Base, engine, get_db
from .models import Service, RequestTrace, LogEntry, AlertRule, Incident
from .schemas import ServiceIn, TraceIn, LogIn, AlertIn, IncidentIn

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Developer Observability Platform API",
    version="1.0.0",
    description="Metrics, traces, logs, alerts and incidents for developer services."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "Developer Observability Platform"}

@app.post("/api/services")
def create_service(payload: ServiceIn, db: Session = Depends(get_db)):
    service = db.query(Service).filter(Service.name == payload.name).first()
    if service:
        service.environment = payload.environment
        service.version = payload.version
        service.last_seen = datetime.now(timezone.utc)
    else:
        service = Service(**payload.model_dump())
        db.add(service)
    db.commit()
    db.refresh(service)
    return service

@app.get("/api/services")
def list_services(db: Session = Depends(get_db)):
    return db.query(Service).order_by(Service.name).all()

@app.post("/api/traces")
def ingest_trace(payload: TraceIn, db: Session = Depends(get_db)):
    trace = RequestTrace(**payload.model_dump())
    db.add(trace)
    service = db.query(Service).filter(Service.name == payload.service).first()
    if service:
        service.last_seen = datetime.now(timezone.utc)
    db.commit()
    db.refresh(trace)
    return trace

@app.post("/api/logs")
def ingest_log(payload: LogIn, db: Session = Depends(get_db)):
    item = LogEntry(**payload.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item

@app.get("/api/logs")
def list_logs(limit: int = 50, db: Session = Depends(get_db)):
    return db.query(LogEntry).order_by(desc(LogEntry.created_at)).limit(min(limit, 200)).all()

@app.get("/api/traces")
def list_traces(limit: int = 100, db: Session = Depends(get_db)):
    return db.query(RequestTrace).order_by(desc(RequestTrace.created_at)).limit(min(limit, 500)).all()

@app.get("/api/metrics/overview")
def metrics_overview(db: Session = Depends(get_db)):
    traces = db.query(RequestTrace).all()
    total = len(traces)
    errors = sum(1 for t in traces if t.status_code >= 500)
    latencies = sorted(t.latency_ms for t in traces)
    avg = mean(latencies) if latencies else 0
    p50 = latencies[max(0, int(len(latencies) * .50) - 1)] if latencies else 0
    p95 = latencies[max(0, int(len(latencies) * .95) - 1)] if latencies else 0
    p99 = latencies[max(0, int(len(latencies) * .99) - 1)] if latencies else 0
    return {
        "request_count": total,
        "error_count": errors,
        "error_rate": round((errors / total) * 100, 2) if total else 0,
        "avg_latency_ms": round(avg, 2),
        "p50_latency_ms": round(p50, 2),
        "p95_latency_ms": round(p95, 2),
        "p99_latency_ms": round(p99, 2),
    }

@app.post("/api/alerts")
def create_alert(payload: AlertIn, db: Session = Depends(get_db)):
    alert = AlertRule(**payload.model_dump())
    db.add(alert)
    db.commit()
    db.refresh(alert)
    return alert

@app.get("/api/alerts")
def list_alerts(db: Session = Depends(get_db)):
    return db.query(AlertRule).order_by(desc(AlertRule.created_at)).all()

@app.post("/api/incidents")
def create_incident(payload: IncidentIn, db: Session = Depends(get_db)):
    incident = Incident(**payload.model_dump())
    db.add(incident)
    db.commit()
    db.refresh(incident)
    return incident

@app.get("/api/incidents")
def list_incidents(db: Session = Depends(get_db)):
    return db.query(Incident).order_by(desc(Incident.created_at)).all()

@app.patch("/api/incidents/{incident_id}/resolve")
def resolve_incident(incident_id: int, db: Session = Depends(get_db)):
    incident = db.get(Incident, incident_id)
    if not incident:
        raise HTTPException(404, "Incident not found")
    incident.status = "resolved"
    incident.resolved_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(incident)
    return incident
