import random, sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))

from app.database import Base, engine, SessionLocal
from app.models import Service, RequestTrace, LogEntry, AlertRule, Incident

Base.metadata.create_all(bind=engine)
db = SessionLocal()

services = ["payments-api", "orders-api", "identity-service", "notification-worker"]
for name in services:
    if not db.query(Service).filter_by(name=name).first():
        db.add(Service(name=name, environment="production", version="2.4.1"))

for i in range(180):
    service = random.choice(services)
    status = random.choices([200, 201, 400, 500, 503], weights=[62, 14, 8, 10, 6])[0]
    latency = max(8, random.gauss(180 if status >= 500 else 95, 45))
    db.add(RequestTrace(
        service=service, method=random.choice(["GET","POST","PUT"]),
        route=random.choice(["/api/users","/api/orders","/api/payments","/health"]),
        status_code=status, latency_ms=round(latency, 2),
        trace_id=f"trace-{i:04d}"
    ))

for i in range(35):
    service = random.choice(services)
    level = random.choice(["INFO","INFO","WARN","ERROR"])
    db.add(LogEntry(
        service=service, level=level,
        message=random.choice([
            "Request completed",
            "Database connection pool nearing capacity",
            "Retrying downstream request",
            "Payment provider timeout"
        ]),
        trace_id=f"trace-{random.randrange(180):04d}"
    ))

if not db.query(AlertRule).first():
    db.add(AlertRule(name="High Error Rate", metric="error_rate", operator=">", threshold=5))
    db.add(AlertRule(name="Slow API", metric="p95_latency_ms", operator=">", threshold=500))

if not db.query(Incident).first():
    db.add(Incident(
        title="Payment provider elevated latency",
        severity="high",
        service="payments-api",
        description="P95 latency crossed the configured threshold."
    ))

db.commit()
db.close()
print("Demo data seeded.")
