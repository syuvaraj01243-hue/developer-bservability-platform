# Developer Observability Platform

A placement-ready full-stack observability platform inspired by lightweight Datadog/New Relic concepts.

## Features
- FastAPI backend
- React + TypeScript frontend
- SQLite by default (easy local setup)
- Service registration and health status
- Request/trace ingestion
- Metrics: request count, error rate, average/P50/P95 latency
- Recent logs
- Alert rules
- Incident lifecycle
- Dashboard with charts
- CORS and typed API client
- Docker Compose included

## Quick start

### Backend
```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m uvicorn app.main:app --reload --port 8000
```

API: http://127.0.0.1:8000
Swagger: http://127.0.0.1:8000/docs

### Frontend
Open another terminal:
```powershell
cd frontend
npm install
npm run dev
```

Frontend: http://localhost:5173

## Demo data
After starting the backend:
```powershell
python scripts/seed_demo.py
```

Then refresh the dashboard.

## Docker
```powershell
docker compose up --build
```

## Architecture

React dashboard -> FastAPI REST API -> SQLite/PostgreSQL-compatible service layer

The project is intentionally structured so PostgreSQL, Redis, OpenTelemetry, Prometheus, or Kafka can be added later without rewriting the UI.
